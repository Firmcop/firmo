// POST /api/order
// Saves an order to Supabase with status 'pending_payment', since no payment
// processor is connected yet. Uses the publishable (anon) key — RLS only
// allows INSERT on this table, so this endpoint cannot read or modify data.

const SUPABASE_URL = 'https://llzifrmwczpejiagqltx.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxsemlmcm13Y3pwZWppYWdxbHR4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODczOTIxMDQsImV4cCI6MjEwMjk2ODEwNH0.YCkag_UIpKapXI7PzNB0F3B1miq3KFOyDtbHQXL6vjY';

function setCors(res){
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

module.exports = async (req, res) => {
  setCors(res);

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed. Use POST.' });
    return;
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch (e) { body = {}; }
  }
  body = body || {};

  const { name, email, phone, address, items, notes } = body;

  if (!name || !email) {
    res.status(400).json({ error: 'name and email are required.' });
    return;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    res.status(400).json({ error: 'A valid email address is required.' });
    return;
  }
  if (!Array.isArray(items) || items.length === 0) {
    res.status(400).json({ error: 'items must be a non-empty array.' });
    return;
  }

  const cleanItems = items.slice(0, 200).map(i => ({
    id: String(i.id || '').slice(0, 100),
    name: String(i.name || '').slice(0, 300),
    price: typeof i.price === 'number' ? i.price : null,
    qty: Number.isFinite(i.qty) ? Math.max(1, Math.floor(i.qty)) : 1,
  }));

  const subtotal = cleanItems.reduce((sum, i) => sum + (typeof i.price === 'number' ? i.price * i.qty : 0), 0);

  const row = {
    customer_name: String(name).slice(0, 200),
    customer_email: String(email).slice(0, 200),
    customer_phone: phone ? String(phone).slice(0, 60) : null,
    shipping_address: address && typeof address === 'object' ? address : null,
    items: cleanItems,
    subtotal: Math.round(subtotal * 100) / 100,
    notes: notes ? String(notes).slice(0, 2000) : null,
  };

  try {
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/orders`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal',
      },
      body: JSON.stringify(row),
    });

    if (!resp.ok) {
      const errText = await resp.text();
      console.error('Supabase insert failed:', resp.status, errText);
      res.status(502).json({ error: 'Could not save your order right now. Please try again shortly.' });
      return;
    }

    res.status(201).json({ ok: true, status: 'pending_payment' });
  } catch (err) {
    console.error('Order submission error:', err);
    res.status(500).json({ error: 'Unexpected server error.' });
  }
};
