// POST /api/quote
// Saves a quote or account request to Supabase. Uses the project's publishable
// (anon) key, which is safe to embed here: row-level security only allows
// INSERT on this table, so this endpoint cannot read, edit, or delete data.

const SUPABASE_URL = 'https://llzifrmwczpejiagqltx.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxsemlmcm13Y3pwZWppYWdxbHR4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODczOTIxMDQsImV4cCI6MjEwMjk2ODEwNH0.YCkag_UIpKapXI7PzNB0F3B1miq3KFOyDtbHQXL6vjY';

function setCors(res){
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

module.exports = async (req, res) => {
  setCors(res);

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed. Use POST.' });
    return;
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch (e) { body = {}; }
  }
  body = body || {};

  const { name, email, company, phone, message, cart, type } = body;

  if (!name || !email) {
    res.status(400).json({ error: 'name and email are required.' });
    return;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    res.status(400).json({ error: 'A valid email address is required.' });
    return;
  }

  const allowedTypes = ['quote', 'account_request'];
  const safeType = allowedTypes.includes(type) ? type : 'quote';

  const row = {
    type: safeType,
    name: String(name).slice(0, 200),
    company: company ? String(company).slice(0, 200) : null,
    email: String(email).slice(0, 200),
    phone: phone ? String(phone).slice(0, 60) : null,
    message: message ? String(message).slice(0, 4000) : null,
    cart_snapshot: Array.isArray(cart) ? cart.slice(0, 100) : null,
  };

  try {
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/quotes`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal',
      },
      body: JSON.stringify(row),
    });

    if (!resp.ok) {
      const errText = await resp.text();
      console.error('Supabase insert failed:', resp.status, errText);
      res.status(502).json({ error: 'Could not save your request right now. Please try again shortly.' });
      return;
    }

    res.status(201).json({ ok: true });
  } catch (err) {
    console.error('Quote submission error:', err);
    res.status(500).json({ error: 'Unexpected server error.' });
  }
};
