/* FirmO shared cart — persists across every page via localStorage. */
window.FirmoCart = (function(){
  const KEY = 'firmo_cart_v1';

  function get(){
    try{
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : [];
    }catch(e){ return []; }
  }

  function set(cart){
    try{ localStorage.setItem(KEY, JSON.stringify(cart)); }catch(e){}
    renderAll();
  }

  // item: {id, name, price (number or null for "quote"), cat, qty}
  function add(item){
    const cart = get();
    const existing = cart.find(c=>c.id===item.id);
    if(existing){ existing.qty += (item.qty || 1); }
    else{ cart.push(Object.assign({qty:1}, item)); }
    set(cart);
  }

  function updateQty(id, qty){
    let cart = get();
    if(qty <= 0){ cart = cart.filter(c=>c.id!==id); }
    else{ const it = cart.find(c=>c.id===id); if(it) it.qty = qty; }
    set(cart);
  }

  function remove(id){
    set(get().filter(c=>c.id!==id));
  }

  function clear(){ set([]); }

  function count(){ return get().reduce((a,c)=>a+c.qty,0); }

  function total(){
    return get().reduce((a,c)=> a + (typeof c.price==='number' ? c.price*c.qty : 0), 0);
  }

  function hasQuoteOnlyItems(){
    return get().some(c=> typeof c.price !== 'number');
  }

  // Renders into whatever cart UI elements exist on the current page.
  function renderAll(){
    const cart = get();
    document.querySelectorAll('[data-cart-count]').forEach(el=>{ el.textContent = count(); });

    const body = document.getElementById('drawerBody');
    if(body){
      if(cart.length===0){
        body.innerHTML = '<div class="drawer-empty">Your cart is empty. Add parts from any catalog page.</div>';
      } else {
        body.innerHTML = cart.map(c=>{
          const priceLabel = typeof c.price==='number' ? '$'+(c.price*c.qty).toFixed(2) : 'Quote';
          return `<div class="drawer-item" data-id="${c.id}">
            <div><div class="name">${c.name}</div><div class="meta">${c.cat||''} · qty
              <button class="qty-mini" data-action="dec" data-id="${c.id}">−</button>
              ${c.qty}
              <button class="qty-mini" data-action="inc" data-id="${c.id}">+</button>
            </div></div>
            <div style="text-align:right;">
              <div class="meta">${priceLabel}</div>
              <button class="remove-mini" data-action="remove" data-id="${c.id}">Remove</button>
            </div>
          </div>`;
        }).join('');
      }
    }

    const totalEl = document.getElementById('drawerTotal');
    if(totalEl){
      const t = total();
      totalEl.textContent = hasQuoteOnlyItems() ? '$'+t.toFixed(2)+' + quoted items' : '$'+t.toFixed(2);
    }
  }

  function initDrawer(){
    const drawer = document.getElementById('drawer');
    const overlay = document.getElementById('drawerOverlay');
    const toggle = document.getElementById('cartToggle');
    const close = document.getElementById('drawerClose');
    if(!drawer || !overlay) return;

    function open(){ drawer.classList.add('open'); overlay.classList.add('open'); drawer.setAttribute('aria-hidden','false'); }
    function shut(){ drawer.classList.remove('open'); overlay.classList.remove('open'); drawer.setAttribute('aria-hidden','true'); }

    if(toggle) toggle.addEventListener('click', open);
    if(close) close.addEventListener('click', shut);
    overlay.addEventListener('click', shut);
    document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') shut(); });

    const body = document.getElementById('drawerBody');
    if(body){
      body.addEventListener('click', (e)=>{
        const btn = e.target.closest('button[data-action]');
        if(!btn) return;
        const id = btn.dataset.id;
        const cart = get();
        const item = cart.find(c=>c.id===id);
        if(!item) return;
        if(btn.dataset.action==='inc') updateQty(id, item.qty+1);
        if(btn.dataset.action==='dec') updateQty(id, item.qty-1);
        if(btn.dataset.action==='remove') remove(id);
      });
    }

    const checkoutBtn = document.getElementById('checkoutBtn');
    if(checkoutBtn){
      checkoutBtn.addEventListener('click', ()=>{
        if(get().length === 0){
          alert('Your cart is empty — add a part before checking out.');
          return;
        }
        toggleCheckoutForm();
      });
    }

    function toggleCheckoutForm(){
      const foot = document.querySelector('.drawer-foot');
      if(!foot) return;
      let form = document.getElementById('checkoutForm');
      if(form){ form.remove(); checkoutBtn.textContent = 'Checkout'; return; }

      checkoutBtn.textContent = 'Cancel';
      form = document.createElement('div');
      form.id = 'checkoutForm';
      form.style.cssText = 'margin-top:14px;padding-top:14px;border-top:1px solid var(--line);display:flex;flex-direction:column;gap:10px;';
      form.innerHTML = `
        <div style="font-family:var(--font-mono);font-size:11px;color:var(--paper-dim);text-transform:uppercase;letter-spacing:.05em;">No payment processor connected yet — this places the order as pending payment.</div>
        <input id="coName" type="text" placeholder="Your name" style="padding:10px 12px;background:var(--ink);border:1px solid var(--line);color:var(--paper);font-size:13.5px;">
        <input id="coEmail" type="email" placeholder="Your email" style="padding:10px 12px;background:var(--ink);border:1px solid var(--line);color:var(--paper);font-size:13.5px;">
        <button class="btn btn-amber" id="coSubmit" style="width:100%;">Place order</button>
        <div id="coMsg" style="font-size:12.5px;"></div>
      `;
      foot.appendChild(form);

      document.getElementById('coSubmit').addEventListener('click', async ()=>{
        const name = document.getElementById('coName').value.trim();
        const email = document.getElementById('coEmail').value.trim();
        const msgEl = document.getElementById('coMsg');
        msgEl.style.color = '';
        if(!name || !email){
          msgEl.textContent = 'Name and email are required.';
          msgEl.style.color = 'var(--rust)';
          return;
        }
        const submitBtn = document.getElementById('coSubmit');
        submitBtn.disabled = true;
        const originalLabel = submitBtn.textContent;
        submitBtn.textContent = 'Placing order...';
        try{
          const resp = await fetch('/api/order', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ name, email, items: get() }),
          });
          if(!resp.ok){
            const data = await resp.json().catch(()=>({}));
            throw new Error(data.error || 'Could not place your order.');
          }
          clear();
          form.innerHTML = '<div style="color:var(--amber);font-size:13.5px;">Order received — status: pending payment. We\'ll follow up by email to arrange payment and confirm shipping.</div>';
          checkoutBtn.textContent = 'Checkout';
        } catch(err){
          msgEl.textContent = err.message || 'Something went wrong. Please try again.';
          msgEl.style.color = 'var(--rust)';
          submitBtn.disabled = false;
          submitBtn.textContent = originalLabel;
        }
      });
    }

    window.FirmoCart._openDrawer = open;
  }

  // Keep the badge/drawer in sync if the cart changes in another tab.
  window.addEventListener('storage', (e)=>{ if(e.key===KEY) renderAll(); });
  document.addEventListener('DOMContentLoaded', ()=>{ initDrawer(); renderAll(); });

  return { get, set, add, updateQty, remove, clear, count, total, renderAll, initDrawer };
})();
