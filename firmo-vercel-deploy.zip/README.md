# FirmO — Vercel deployment package

This folder is a complete Vercel project: the static storefront plus a small
Node.js API (`/api/quote`, `/api/order`) that saves data to Supabase.

## What's inside
- `index.html` — homepage (same content as `firmo-site.html`, kept as a duplicate
  since other pages link to `firmo-site.html` by name)
- `firmo-*-catalog.html` — the four product catalogs (bearings, seals, belts, grease)
- `firmo-search.html` — sitewide search across all catalogs
- `firmo-cart.js` — shared cart (browser localStorage), loaded by every page
- `firmo-shipping-returns.html`, `firmo-privacy-policy.html`, `firmo-terms.html` — policy pages
- `api/quote.js` — `POST /api/quote`, saves quote & account requests to Supabase
- `api/order.js` — `POST /api/order`, saves orders to Supabase (status: `pending_payment` — no payment processor connected yet)
- `vercel.json` — minimal config (no special routing needed; Vercel auto-detects static files + `/api` as serverless functions)

## How to deploy

### Option A — Vercel dashboard (no CLI needed)
1. Go to https://vercel.com/new
2. Choose "Deploy without Git" / drag-and-drop, and upload this whole folder
   (or a zip of it — Vercel will unzip it automatically).
3. Framework preset: choose "Other". Leave build command and output directory blank.
4. Click Deploy.

### Option B — Vercel CLI
```bash
npm i -g vercel
cd this-folder
vercel --prod
```
Follow the prompts (link to your account/team, accept defaults).

## Backend notes
- The API routes use a Supabase project (`firmo`) that's already set up with
  `quotes` and `orders` tables and row-level security enabled. The Supabase URL
  and public/anon key are embedded directly in `api/quote.js` and `api/order.js`
  — this is safe because the anon key only has INSERT permission on these two
  tables (no read, update, or delete), enforced by RLS policies in the database.
- No payment processor is connected. Orders save with `status: 'pending_payment'`.
  To take real payments, add Stripe (or similar) and update `api/order.js` to
  create a checkout session instead of (or in addition to) the Supabase insert.
- No email notifications are sent yet. To get notified of new quotes/orders,
  either poll the Supabase tables, set up a Supabase database webhook, or add
  an email API call (e.g. Resend, SendGrid) inside `api/quote.js` / `api/order.js`.
- Reading submitted quotes/orders requires the Supabase dashboard (SQL editor
  or Table Editor) — the site itself has no read access to this data.
